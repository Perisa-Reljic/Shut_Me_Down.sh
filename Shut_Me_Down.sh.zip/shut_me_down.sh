#!/bin/bash
# Author: Relic Perisa 🔻(С)
# Domain: perisareljic.name

# Enable command tracing for verification
set -x

# Explicitly set paths and screen display
export DISPLAY=:0
export PATH=$PATH:/usr/bin:/usr/sbin:/sbin

# Dynamically locate the user's DBUS address (required for background VLC checks)
USER_ID=$(id -u)
export DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$USER_ID/bus"

IDLE_TIME_LIMIT=420000 # 420 seconds (7 minutes)
CHECK_INTERVAL=10      # Check every 10 seconds

echo "DEBUG: Script started..."

while true; do
    # Check idle time
    CURRENT_IDLE=$(xprintidle 2>/dev/null)
    
    # If xprintidle fails or is missing, log error
    if [ -z "$CURRENT_IDLE" ]; then
        echo "ERROR: xprintidle is not installed or cannot access the display!"
        sleep 10
        continue
    fi

    echo "DEBUG: Current inactivity: $CURRENT_IDLE ms"

    if [ "$CURRENT_IDLE" -gt "$IDLE_TIME_LIMIT" ]; then
        echo "DEBUG: Time limit reached, checking VLC status..."
        
        # Check VLC status (MPRIS via DBUS)
        VLC_STATUS=$(dbus-send --print-reply --dest=org.mpris.MediaPlayer2.vlc /org/mpris/MediaPlayer2 org.freedesktop.DBus.Properties.Get string:'org.mpris.MediaPlayer2.Player' string:'PlaybackStatus' 2>/dev/null | grep -Po '(?<=")\w+(?=")')
        
        echo "DEBUG: VLC status is: [$VLC_STATUS]"

        if [ "$VLC_STATUS" = "Playing" ]; then
            echo "DEBUG: VLC is still playing media. Skipping shutdown."
        else
            echo "DEBUG: VLC is closed or paused. Initiating shutdown sequence!"
            notify-send "System Inactive" "Shutting down in 60s..."
            
            sleep 60
            
            # Final check before powering off
            FINAL_IDLE=$(xprintidle)
            if [ "$FINAL_IDLE" -gt 60000 ]; then
                echo "DEBUG: EXECUTING SHUTDOWN!"
                sudo poweroff
            else
                echo "DEBUG: Activity detected at the last moment, aborting."
            fi
        fi
    fi
    sleep $CHECK_INTERVAL
done
